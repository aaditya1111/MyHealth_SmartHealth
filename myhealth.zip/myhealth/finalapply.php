<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even) {
    background-color: #dddddd;
}


</style>
</head>
<body>

<h1 style="color:red;margin-left:30px; font-family:Times New Roman; font-size:50px; font-style:italic;"><u>Personal Information</u></h1>
<form name="f1" Action="applyinsert.php" Method="POST" enctype="multipart/form-data" >

<br>
<br>
First Name<input type="Text" size=30 maxsize=10 name="fname" required/>      Middle Name<input type="Text" size=30 maxsize=10 name="mname"/>    Last Name<input type="Text" size=30 maxsize=10 name="lname" required/>
<br>
<br>
Date of Birth<input type="date" name="bday"/>
<br>
<br>
Gender
<input type="radio" name="gender" value="female"/>Female
<input type="radio" name="gender" value="male"/>Male
<input type="radio" name="gender" value="other"/>Other
<br>
<br>
Contact:<input type="text" name="no1" size="10" maxlength="10" />
<br>
E-mail: <input type="email" name="usremail"/>
<br>
<br>
<br>
<p1 style="color:green;margin-left:30px;">Address</p1>
<br>
<br>
House/Wing no.<input type="Text" size=30 maxsize=10 name="a1" required/>
<br><br>
Street/Building name<input type="Text" size=30 maxsize=10 name="a2" required/>
<br><br>
Landmark/Area<input type="Text" size=30 maxsize=10 name="a3" required/>
<br>
Country<input type="Text" size=30 maxsize=10 name="l1" required/>
<br>
State<input type="Text" size=30 maxsize=10 name="l2" required/>
<br>
City<input type="Text" size=30 maxsize=10 name="l3" required/>
<br>
<br>
<br>
Upload your Resume
<br> <input type="file" name="file" id="file"/>
<br>
<br>

<h2 style="color:red;margin-left:30px; font-family:Times New Roman; font-size:50px; font-style:italic;"><u>Education and Training</u></h2>
<br>
<br>

<table>
  <tr>
    <th>#</th>
    <th>Start Date</th>
    <th>End date</th>
	<th>Board/University</th>
	<th>Subjects/Degree</th>
	<th>Country</th>
  </tr>
  <tr>
  
	<td>High School</td>
	<td><input type="Date" name="c1" required></td>
	<td><input type="Date" name="c2" required></td>
	<td><input type="text" name="c3" required></td>
	<td><input type="text" name="c4" required></td>
   <td><input type="text" name="c5" required></td>
   

  </tr>
  <tr>
  
	<td>Intermediate</td>
	<td><input type="Date" name="c6" required></td>
	<td><input type="Date" name="c7" required></td>
	<td><input type="text" name="c8" required></td>
	<td><input type="text" name="c9" required></td>
   <td><input type="text" name="c10" required></td>
   

  </tr>
  <tr>
  
	<td>College(UG/PG)</td>
	<td><input type="Date" name="c11" required></td>
	<td><input type="Date" name="c12" required></td>
	<td><input type="text" name="c13" required></td>
	<td><input type="text" name="c14" required></td>
   <td><input type="text" name="c15" required></td>
  

  </tr>
  <tr>
  
	<td>training/Internship(if any)</td>
	<td><input type="Date" name="c16"></td>
	<td><input type="Date" name="c17"></td>
	<td><input type="text" name="c18" ></td>
	<td><input type="text" name="c19" ></td>
   <td><input type="text" name="c20" ></td>
   

  </tr>
  
  

  </tr>
</table>
<br>
<br>
<h3 style="color:red;margin-left:30px; font-family:Times New Roman; font-size:50px;font-style:italic;"><u>Additional Information</u></h3>
<br>
<br>
<p style="color:blue;margin-left:30px;">Fresher can skip this page</p>
<br>
<br>
Organisation/Industry <input type="Text" size=30 maxsize=10 name="organisation" >    
<br>
<br>
Start Date<input type="date" name="sday"/>
<br>
End date<input type="date" name="lday"/>
<br>
<br>
Job Role<input type="Text" size=30 maxsize=10 name="jr" />
<br>
Country<input type="Text" size=30 maxsize=10 name="s1" />
<br>
State<input type="Text" size=30 maxsize=10 name="s2" />
<br>
City<input type="Text" size=30 maxsize=10 name="s3" />

<br>
<br>
<p1 style="color:green;margin-left:30px;">Reference Details</p1>
<br>
<br>
Name<input type="Text" size=30 maxsize=10 name="rname" />
<br>
Contact no.<input type="text" name="no2" size="10" maxlength="10" />
<br>
E-mail id <input type="email" name="refemail"/>
<br>
<br>
<br>
<Input type="Submit">
</form>


</body>