<!DOCTYPE html>
<html lang="en">

<head>
    <title>myHealth|SignUp</title>
    <!-- meta tags -->
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="keywords" content="myHeath, Health Portal, Pateint Data" />
    <!-- /meta tags -->
    <!-- custom style sheet -->
    <link href="web/css/style.css" rel="stylesheet" type="text/css" />
    <!-- /custom style sheet -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <!-- fontawesome css -->
    <link href="web/css/fontawesome-all.css" rel="stylesheet" />
    <!-- /fontawesome css -->
    <!-- google fonts-->
    <link href="//fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <!-- /google fonts-->

    <script type="text/javascript">
        function changeIcon(that) {
            if (that.value=="male") {
                document.getElementById('gender-icon').className="fa fa-mars";
            } else if (that.value=="female") {
                document.getElementById('gender-icon').className="fa fa-venus";
            } else {
                document.getElementById('gender-icon').className="fa fa-genderless"
            }
        }
    </script>

</head>


<body>
    <!-- TODO -- SignUp Logo -->
    <div class="signup-logo">
        <img class="center-block" style="width: 20%; height: 20%" src="PICS/signup.png" alt="SignUp Logo">
    </div>
    <div class="w3l-login-form">
        <form action="action_signup.php" method="POST">

            <div class=" w3l-form-group">
                <label>First Name</label>
                <div class="group">
                    <i class="fas fa-user"></i>
                    <input type="text" class="form-control" name="patient_fname" placeholder="First Name" required="required" />
                </div>
            </div>
            <div class=" w3l-form-group">
                <label>Last Name</label>
                <div class="group">
                    <i class="fas fa-user"></i>
                    <input type="text" class="form-control" name="patient_lname" placeholder="Last Name" required="required" />
                </div>
            </div>
            <div class=" w3l-form-group">
                <label>Mobile No.</label>
                <div class="group">
                    <i class="fas fa-phone"></i>
                    <input type="text" class="form-control" name="mobile_no" placeholder="Mobile No" required="required" />
                </div>
            </div>
            <div class=" w3l-form-group">
                <label for="gender">Gender:</label>
                <div class="group">
                    <i id="gender-icon" class="fas fa-mars"></i>
                    <select class="form-control" name="gender" onchange="changeIcon(this)">
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                </select>
                </div>
            </div>
            <div class=" w3l-form-group">
                <label>DOB</label>
                <div class="group">
                    <i class="fas fa-calendar"></i>
                    <input type="date" class="form-control" name="dob" placeholder="DOB" required="required" />
                </div>
            </div>
            <div class=" w3l-form-group">
                <label>Email:</label>
                <div class="group">
                    <i class="fas fa-envelope"></i>
                    <input type="text" class="form-control" name="email" placeholder="Email" required="required" />
                </div>
            </div>
            <div class=" w3l-form-group">
                <label>Password:</label>
                <div class="group">
                    <i class="fas fa-unlock"></i>
                    <input type="password" class="form-control" name="pwd" placeholder="Password" required="required" />
                </div>
            </div>
            <div class=" w3l-form-group">
                <label>Confirm Password:</label>
                <div class="group">
                    <i class="fas fa-unlock"></i>
                    <input type="password" class="form-control" name="confirmpwd" placeholder="Confirm Password" required="required" />
                </div>
            </div>
            <!--<div class="forgot">
                <a href="#">Forgot Password?</a>
                <p><input type="checkbox">Remember Me</p>
            </div>-->
            <button type="submit" name="signup-submit">Sign Up</button>
        </form>
        <p class=" w3l-register-p">Already a member?<a href="login.php" class="register"> Login</a></p>
    </div>
    <footer>
        <p class="copyright-agileinfo"> &copy; 2019 HackinCity Project. All Rights Reserved | Design by <a href="">Aaditya-Aman-Varun</a></p>
    </footer>

</body>
</html>