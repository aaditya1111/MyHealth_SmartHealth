<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="style.css">
  <title>Login Page</title>
  <head>
    <body>
      <div id="loginpage">
        <form action="Homepage.html" method="post">
          <fieldset>
            <legend style="font-family:Arabic;font-size:30px;color:#000000;">Login</legend>
          <label id="label">Email:</label>
          <input type="text" name="Email" required>
          <br><br>
          <label id="label">Password:</label>
          <input type="password" name="passw" required>
          <input type="submit" value="submit"> <br> <br>
          <a href="Regiter.php">Not A member yet! Sign Up!></a>
          </fieldset>
       </form>
      </div>
    </body>
    </html>
